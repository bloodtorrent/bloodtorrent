require 'configatron'

configatron.domain = ""
configatron.user = ""
configatron.password = ""
configatron.url = ""
configatron.demo_mode = true
configatron.demo_file_name = "sample_data.xml"
configatron.test_mode = false
configatron.test_file_name = "live_data.xml"