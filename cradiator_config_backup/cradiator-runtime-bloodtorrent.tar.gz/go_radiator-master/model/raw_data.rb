class RawData
  attr_accessor :pipeline_name, :stage_name, :job_name, :activity, :last_build_label, :last_build_status, :last_build_date_time
end